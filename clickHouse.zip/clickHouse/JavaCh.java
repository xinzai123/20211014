package com.mshbj.choperator;

import com.sun.org.apache.bcel.internal.generic.NEW;
import ru.yandex.clickhouse.BalancedClickhouseDataSource;
import ru.yandex.clickhouse.ClickHouseConnection;
import ru.yandex.clickhouse.ClickHouseStatement;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

/**
 *  Java 操作ClickHouse api
 */
public class JavaCh {
    public static void main(String[] args) throws SQLException {
        Properties props = new Properties();
        props.setProperty("user","default" );
        props.setProperty("password","" );
        //连接Clickhouse 配置
        BalancedClickhouseDataSource bcd = new BalancedClickhouseDataSource("jdbc:clickhouse://node1:8123/newdb", props);
        //建立连接
        ClickHouseConnection conn = bcd.getConnection();
        //查询语句对象
        ClickHouseStatement statement = conn.createStatement();

        //插入数据
        statement.execute("insert into t_java values (4,'ml',21),(5,'tt',22)");

        //查询ClickHouse数据
        ResultSet rs = statement.executeQuery("select id,name,age from  t_java");

        //获取打印数据：
        while(rs.next()){
            int id = rs.getInt(1);
            String name = rs.getString("name");
            int age = rs.getInt(3);

            System.out.println("id = "+id+",name = "+name+",age = "+age);
        }




    }
}
