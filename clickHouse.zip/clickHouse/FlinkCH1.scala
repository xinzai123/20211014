package com.mshbj.choperator.scalacode

import org.apache.flink.api.common.typeinfo.Types
import org.apache.flink.api.java.io.jdbc.JDBCAppendTableSink
import org.apache.flink.streaming.api.scala.{DataStream, StreamExecutionEnvironment}
import org.apache.flink.table.api.{EnvironmentSettings, Table}
import org.apache.flink.table.api.scala.StreamTableEnvironment

/**
  *  Flink1.10.x 版本之前 使用 flink-jdbc 包操作ClickHouse，只支持Table Api
  */

case class PersonInfo(id:Int,name:String,age:Int)

object FlinkCH1 {
  def main(args: Array[String]): Unit = {
    //创建Flink Stream env 对象
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    env.setParallelism(1)
    import org.apache.flink.streaming.api.scala._

    //创建Flink tableenv 对象
    val settings: EnvironmentSettings = EnvironmentSettings.newInstance().inStreamingMode().useBlinkPlanner().build()
    val tableEnv: StreamTableEnvironment = StreamTableEnvironment.create(env,settings)

    //读取Socket数据，将数据实时写入ClickHouse
    val ds1: DataStream[String] = env.socketTextStream("node5",9999)

    //10,zs,10
    val ds2: DataStream[PersonInfo] = ds1.map(line => {
      val arr: Array[String] = line.split(",")
      val id: Int = arr(0).toInt
      val name: String = arr(1)
      val age: Int = arr(2).toInt
      PersonInfo(id, name, age)
    })

    //将DataStream对象转换成Table对象
    import org.apache.flink.table.api.scala._
    val table: Table = tableEnv.fromDataStream(ds2,'id,'name,'age)


    //准备Sink 对象
    val sink: JDBCAppendTableSink = JDBCAppendTableSink.builder()
      .setBatchSize(2)
      .setDBUrl("jdbc:clickhouse://node1:8123/newdb")
      .setDrivername("ru.yandex.clickhouse.ClickHouseDriver")
      .setUsername("default")
      .setPassword("")
      .setQuery("insert into t_java values (?,?,?)")
      .setParameterTypes(Types.INT, Types.STRING, Types.INT)
      .build()

    tableEnv.registerTableSink("selfSink",sink.configure(Array[String]("id","name","age"),
      Array(Types.INT, Types.STRING, Types.INT)))

    tableEnv.insertInto(table,"selfSink")

    env.execute()




  }

}
