import java.util.Date

object TestData {

  def main(args: Array[String]): Unit = {
//    var date =new Date(1592722028000L)
//    println(date)
    print(1<<27)
  }
}
